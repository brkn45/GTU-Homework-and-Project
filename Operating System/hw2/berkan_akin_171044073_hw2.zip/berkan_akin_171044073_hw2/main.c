#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#define BLOCK_SIZE 1024
#define MAX_BLOCKS 4096
#define MAX_FILES 100
#define FILENAME_LEN 30
#define MAX_PATH_LEN 1024
#define PASSWORD_LEN 20
#define MAX_FILENAME 255
#define FAT_SIZE (MAX_BLOCKS * 3 / 2)  // Each entry is 12 bits, so 1.5 bytes per block

typedef struct {
    char name[FILENAME_LEN];
    int size;
    int start_block;
    int num_blocks;
    char permissions[3]; // rw
    char creation_time[20];
    char modification_time[20];
    char password[PASSWORD_LEN];
} File;

typedef struct Directory {
    char name[FILENAME_LEN];
    struct Directory *subdirectories[MAX_FILES];
    File files[MAX_FILES];
    int subdirectory_count;
    int file_count;
} Directory;

typedef struct {
    char name[FILENAME_LEN];
    int block_size;
    int num_blocks;
    int free_blocks;
    int num_files;
    int num_dir;
    Directory root;
    char *data;
    unsigned char fat[FAT_SIZE];  // FAT12 table
} FileSystem;

FileSystem fs;

void write_directory_to_file(Directory *dir, FILE *file) {
    fwrite(dir->name, sizeof(char), FILENAME_LEN, file);
    fwrite(&dir->subdirectory_count, sizeof(int), 1, file);
    fwrite(&dir->file_count, sizeof(int), 1, file);

    for (int i = 0; i < dir->file_count; i++) {
        fwrite(dir->files[i].name, sizeof(char), FILENAME_LEN, file);
        fwrite(&dir->files[i].size, sizeof(int), 1, file);
        fwrite(&dir->files[i].start_block, sizeof(int), 1, file);
        fwrite(&dir->files[i].num_blocks, sizeof(int), 1, file);
        fwrite(dir->files[i].permissions, sizeof(char), 3, file);
        fwrite(dir->files[i].creation_time, sizeof(char), 20, file);
        fwrite(dir->files[i].modification_time, sizeof(char), 20, file);
        fwrite(dir->files[i].password, sizeof(char), PASSWORD_LEN, file);
    }

    for (int i = 0; i < dir->subdirectory_count; i++) {
        write_directory_to_file(dir->subdirectories[i], file);
    }
}

void read_directory_from_file(Directory *dir, FILE *file) {
    fread(dir->name, sizeof(char), FILENAME_LEN, file);
    fread(&dir->subdirectory_count, sizeof(int), 1, file);
    fread(&dir->file_count, sizeof(int), 1, file);

    for (int i = 0; i < dir->file_count; i++) {
        fread(dir->files[i].name, sizeof(char), FILENAME_LEN, file);
        fread(&dir->files[i].size, sizeof(int), 1, file);
        fread(&dir->files[i].start_block, sizeof(int), 1, file);
        fread(&dir->files[i].num_blocks, sizeof(int), 1, file);
        fread(dir->files[i].permissions, sizeof(char), 3, file);
        fread(dir->files[i].creation_time, sizeof(char), 20, file);
        fread(dir->files[i].modification_time, sizeof(char), 20, file);
        fread(dir->files[i].password, sizeof(char), PASSWORD_LEN, file);
    }

    for (int i = 0; i < dir->subdirectory_count; i++) {
        dir->subdirectories[i] = malloc(sizeof(Directory));
        read_directory_from_file(dir->subdirectories[i], file);
    }
}

void saveFileSystem(const char *filename) {
    FILE *file = fopen(filename, "wb");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    fwrite(fs.name, sizeof(char), FILENAME_LEN, file);
    fwrite(&fs.block_size, sizeof(int), 1, file);
    fwrite(&fs.num_blocks, sizeof(int), 1, file);
    fwrite(&fs.free_blocks, sizeof(int), 1, file);
    fwrite(&fs.num_files, sizeof(int), 1, file);
    fwrite(&fs.num_dir, sizeof(int), 1, file);

    fwrite(fs.fat, sizeof(unsigned char), FAT_SIZE, file);  // Save FAT12 table
    write_directory_to_file(&fs.root, file);

    fwrite(fs.data, sizeof(char), fs.num_blocks * fs.block_size, file);  // Save data

    fclose(file);
    printf("File system saved to: %s\n", filename);
}

void loadFileSystem(const char *filename) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    fread(fs.name, sizeof(char), FILENAME_LEN, file);
    fread(&fs.block_size, sizeof(int), 1, file);
    fread(&fs.num_blocks, sizeof(int), 1, file);
    fread(&fs.free_blocks, sizeof(int), 1, file);
    fread(&fs.num_files, sizeof(int), 1, file);
    fread(&fs.num_dir, sizeof(int), 1, file);

    fread(fs.fat, sizeof(unsigned char), FAT_SIZE, file);  // Load FAT12 table
    read_directory_from_file(&fs.root, file);

    fs.data = (char *)malloc(fs.num_blocks * fs.block_size);
    fread(fs.data, sizeof(char), fs.num_blocks * fs.block_size, file);  // Load data

    fclose(file);
    printf("File system loaded from: %s\n", filename);
}

void createFileSystem(const char *name, float block_size) {
    strcpy(fs.name, name);
    fs.block_size = block_size * 1024;
    fs.num_blocks = MAX_BLOCKS;  // 4 MB file system
    fs.free_blocks = fs.num_blocks;
    fs.num_files = 0;
    fs.num_dir=1;
    strcpy(fs.root.name, "\\");
    fs.root.subdirectory_count = 0;
    fs.root.file_count = 0;
    fs.data = (char *)malloc(fs.num_blocks * fs.block_size);
    memset(fs.data, 0, fs.num_blocks * fs.block_size);
    memset(fs.fat, 0, FAT_SIZE);  // Initialize FAT12 table
    printf("File system created with block size: %f KB\n", block_size);
}

Directory *findDirectory(Directory *currentDir, const char *name) {
    for (int i = 0; i < currentDir->subdirectory_count; i++) {
        if (strcmp(currentDir->subdirectories[i]->name, name) == 0) {
            return currentDir->subdirectories[i];
        }
    }
    return NULL;
}

Directory *navigateToDirectory(const char *path) {
    char path_copy[MAX_PATH_LEN];
    strcpy(path_copy, path);
    char *token = strtok(path_copy, "\\");
    Directory *currentDir = &fs.root;

    while (token != NULL) {
        currentDir = findDirectory(currentDir, token);
        if (currentDir == NULL) {
            return NULL;
        }
        token = strtok(NULL, "\\");
    }
    return currentDir;
}

void splitPath(const char *path, char *parent_path, char *name) {
    strcpy(parent_path, path);
    char *last_slash = strrchr(parent_path, '\\');
    if (last_slash != NULL) {
        strcpy(name, last_slash + 1);
        *last_slash = '\0';
    } else {
        strcpy(name, parent_path);
        strcpy(parent_path, "\\");
    }
}

int allocateCluster() {
    for (int i = 0; i < fs.num_blocks; i++) {
        int index = i * 3 / 2;
        int value;
        if (i % 2 == 0) {
            value = fs.fat[index] | (fs.fat[index + 1] << 8);
            value &= 0xFFF;
        } else {
            value = (fs.fat[index] >> 4) | (fs.fat[index + 1] << 4);
            value &= 0xFFF;
        }
        if (value == 0) {
            fs.free_blocks--;
            return i;
        }
    }
    return -1;
}

void updateFAT(int cluster, int value) {
    int index = cluster * 3 / 2;
    if (cluster % 2 == 0) {
        fs.fat[index] = value & 0xFF;
        fs.fat[index + 1] = (fs.fat[index + 1] & 0xF0) | ((value >> 8) & 0x0F);
    } else {
        fs.fat[index] = (fs.fat[index] & 0x0F) | ((value << 4) & 0xF0);
        fs.fat[index + 1] = (value >> 4) & 0xFF;
    }
}

int getFATValue(int cluster) {
    int index = cluster * 3 / 2;
    if (cluster % 2 == 0) {
        return (fs.fat[index] | (fs.fat[index + 1] << 8)) & 0xFFF;
    } else {
        return ((fs.fat[index] >> 4) | (fs.fat[index + 1] << 4)) & 0xFFF;
    }
}

void writeToFile(const char *path, const char *linuxFile,const char *password) {
    char parent_path[MAX_PATH_LEN];
    char file_name[FILENAME_LEN];
    splitPath(path, parent_path, file_name);

    Directory *parentDir = navigateToDirectory(parent_path);
    if (parentDir == NULL) {
        printf("Directory not found: %s\n", parent_path);
        return;
    }

    FILE *file = fopen(linuxFile, "rb");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    File *existingFile = NULL;
    for (int i = 0; i < parentDir->file_count; i++) {
        

        if (strcmp(parentDir->files[i].name, file_name) == 0) {
            if (strlen(parentDir->files[i].password) > 0 && strcmp(parentDir->files[i].password, password) != 0) {
            printf("Password incorrect for file: %s\n", file_name);
            return;
        }
        if (strchr(parentDir->files[i].permissions, '+') == NULL) {
            printf("Read permission denied for file: %s\n", file_name);
            return;
        }
        if (strchr(parentDir->files[i].permissions, 'w') == NULL) {
            printf("Read permission denied for file: %s\n", file_name);
            return;
        }
            existingFile = &parentDir->files[i];
            break;
        }
    }

    if (existingFile != NULL) {
        // If file exists, clear its data in the FAT
        int current_block = existingFile->start_block;
        while (current_block != 0xFFF) {
            int next_block = getFATValue(current_block);
            updateFAT(current_block, 0);  // Mark block as free
            current_block = next_block;
        }
        existingFile->size = 0;
        existingFile->num_blocks = 0;
    } else {
        // Create a new file
        existingFile = &parentDir->files[parentDir->file_count++];
        strcpy(existingFile->name, file_name);
        existingFile->size = 0;
        existingFile->num_blocks = 0;
        strcpy(existingFile->permissions, "+rw");
        time_t now = time(NULL);
        strftime(existingFile->creation_time, 20, "%Y-%m-%d %H:%M:%S", localtime(&now));
        strcpy(existingFile->modification_time, existingFile->creation_time);
        strcpy(existingFile->password, "");
        fs.num_files++;
    }

    existingFile->start_block = allocateCluster();
    if (existingFile->start_block == -1) {
        printf("No free blocks available.\n");
        fclose(file);
        return;
    }

    int current_block = existingFile->start_block;
    int prev_block = -1;

    int bytesRead;
    while ((bytesRead = fread(fs.data + current_block * fs.block_size, 1, fs.block_size, file)) > 0) {
        existingFile->size += bytesRead;
        existingFile->num_blocks++;
        if (prev_block != -1) {
            updateFAT(prev_block, current_block);
        }
        prev_block = current_block;
        current_block = allocateCluster();
        if (current_block == -1 && !feof(file)) {
            printf("No free blocks available.\n");
            updateFAT(prev_block, 0xFFF);  // Mark end of file
            fclose(file);
            return;
        }
    }

    if (prev_block != -1) {
        updateFAT(prev_block, 0xFFF);  // End of file marker
    }

    time_t now = time(NULL);
    strftime(existingFile->modification_time, 20, "%Y-%m-%d %H:%M:%S", localtime(&now));

    fclose(file);
    printf("File written: %s\n", linuxFile);
}

void readFromFile(const char *path, const char *linuxFile, const char *password) {
    char parent_path[MAX_PATH_LEN];
    char file_name[FILENAME_LEN];
    splitPath(path, parent_path, file_name);

    Directory *parentDir = navigateToDirectory(parent_path);
    if (parentDir == NULL) {
        printf("Directory not found: %s\n", parent_path);
        return;
    }

    for (int i = 0; i < parentDir->file_count; i++) {
        if (strcmp(parentDir->files[i].name, file_name) == 0) {
            if (strlen(parentDir->files[i].password) > 0 && strcmp(parentDir->files[i].password, password) != 0) {
                printf("Password incorrect for file: %s\n", file_name);
                return;
            }
            if (strchr(parentDir->files[i].permissions, '+') == NULL) {
                printf("Read permission denied for file: %s\n", file_name);
                return;
            }
            if (strchr(parentDir->files[i].permissions, 'r') == NULL) {
                printf("Read permission denied for file: %s\n", file_name);
                return;
            }

            FILE *file = fopen(linuxFile, "wb");
            if (!file) {
                perror("Failed to open file");
                return;
            }

            int current_block = parentDir->files[i].start_block;
            int total_bytes_read = 0;
            while (current_block != 0xFFF) {
                int bytes_to_read = fs.block_size;
                if (total_bytes_read + bytes_to_read > parentDir->files[i].size) {
                    bytes_to_read = parentDir->files[i].size - total_bytes_read;
                }
                fwrite(fs.data + current_block * fs.block_size, 1, bytes_to_read, file);
                total_bytes_read += bytes_to_read;
                current_block = getFATValue(current_block);
            }

            fclose(file);
            printf("File read: %s\n", linuxFile);
            return;
        }
    }
    printf("File not found: %s\n", file_name);
}

void deleteFile(const char *path) {
    char parent_path[MAX_PATH_LEN];
    char file_name[FILENAME_LEN];
    splitPath(path, parent_path, file_name);

    Directory *parentDir = navigateToDirectory(parent_path);
    if (parentDir == NULL) {
        printf("Directory not found: %s\n", parent_path);
        return;
    }

    for (int i = 0; i < parentDir->file_count; i++) {
        if (strcmp(parentDir->files[i].name, file_name) == 0) {
            int current_block = parentDir->files[i].start_block;
            while (current_block != 0xFFF) {
                int next_block = getFATValue(current_block);
                updateFAT(current_block, 0);  // Mark as free
                current_block = next_block;
            }
            fs.free_blocks += parentDir->files[i].num_blocks;

            for (int j = i; j < parentDir->file_count - 1; j++) {
                parentDir->files[j] = parentDir->files[j + 1];
            }
            parentDir->file_count--;
            fs.num_files--;
            printf("File deleted: %s\n", file_name);
            fs.num_files--;
            return;
        }
    }
    printf("File not found: %s\n", file_name);
}

void listDirectory(const char *path) {
    Directory *currentDir = navigateToDirectory(path);
    if (currentDir == NULL) {
        printf("Directory not found: %s\n", path);
        return;
    }

    for (int i = 0; i < currentDir->subdirectory_count; i++) {
        printf("dir  %s\n", currentDir->subdirectories[i]->name);
    }

    for (int i = 0; i < currentDir->file_count; i++) {
        printf("%s %d %s %s %s %s\n", currentDir->files[i].permissions, currentDir->files[i].size, currentDir->files[i].creation_time, currentDir->files[i].modification_time, currentDir->files[i].name, strlen(currentDir->files[i].password) > 0 ? "protected" : "");
    }
}
void listBlocks(File *file) {
    int current_block = file->start_block;
    printf("Blocks for %s: ", file->name);
    while (current_block != 0xFFF) {
        printf("%d ", current_block);
        current_block = getFATValue(current_block);
    }
    printf("\n");
}

void printDirectoryDetails(Directory *dir, int level) {
    for (int i = 0; i < dir->file_count; i++) {
        listBlocks(&dir->files[i]);
        //for (int j = 0; j < level; j++)
        printf("| %-20s | %10d | %11d | %7d | %-3s | %-20s | %-20s | %s\n",
               dir->files[i].name,
               dir->files[i].size,
               dir->files[i].start_block,
               dir->files[i].num_blocks,
               dir->files[i].permissions,
               dir->files[i].creation_time,
               dir->files[i].modification_time,
               strlen(dir->files[i].password) > 0 ? "Yes" : "No");
    }

    for (int i = 0; i < dir->subdirectory_count; i++) {
        printDirectoryDetails(dir->subdirectories[i], level + 1);
    }
}

void dumpFileSystem() {
    printf("File System Name: %s\n", fs.name);
    printf("Block size: %d bytes\n", fs.block_size);
    printf("Total blocks: %d\n", fs.num_blocks);
    printf("Free blocks: %d\n", fs.free_blocks);
    printf("Total directory: %d\n", fs.num_dir);
    printf("Total files: %d\n", fs.num_files);
    printf("\n");
    printf("| %-20s | %10s | %11s | %7s | %-3s | %-20s | %-20s | %-3s |\n",
           "Name", "Size", "Start Block", "Blocks", "Permissions", "Creation Time", "Modification Time", "Password Protected");
    printf("|----------------------|------------|-------------|---------|-------------|----------------------|----------------------|--------------------|\n");
    printDirectoryDetails(&fs.root, 1);
}
void chmodFile(const char *path, const char *permissions) {
    char parent_path[MAX_PATH_LEN];
    char file_name[FILENAME_LEN];
    splitPath(path, parent_path, file_name);

    Directory *parentDir = navigateToDirectory(parent_path);
    if (parentDir == NULL) {
        printf("Directory not found: %s\n", parent_path);
        return;
    }

    for (int i = 0; i < parentDir->file_count; i++) {
        if (strcmp(parentDir->files[i].name, file_name) == 0) {
            strcpy(parentDir->files[i].permissions, permissions);
            printf("File permissions changed: %s ,%s\n", path,permissions);
            return;
        }
    }
    printf("File not found: %s\n", file_name);
}

void addPassword(const char *path, const char *password) {
    char parent_path[MAX_PATH_LEN];
    char file_name[FILENAME_LEN];
    splitPath(path, parent_path, file_name);

    Directory *parentDir = navigateToDirectory(parent_path);
    if (parentDir == NULL) {
        printf("Directory not found: %s\n", parent_path);
        return;
    }

    for (int i = 0; i < parentDir->file_count; i++) {
        if (strcmp(parentDir->files[i].name, file_name) == 0) {
            strcpy(parentDir->files[i].password, password);
            printf("Password added to file: %s\n", path);
            return;
        }
    }
    printf("File not found: %s\n", file_name);
}

void removeQuotes(char *str) {
    size_t len = strlen(str);
    if (len > 0) {
        if (str[0] == '"') {
            memmove(str, str + 1, len);
            len--;
        }
        if (len > 0 && str[len - 1] == '"') {
            str[len - 1] = '\0';
        }
    }
}

void makeDirectory(const char *path) {
    char parent_path[MAX_PATH_LEN];
    char dir_name[FILENAME_LEN];
    splitPath(path, parent_path, dir_name);
    
    Directory *parentDir = navigateToDirectory(parent_path);
    if (parentDir == NULL) {
        printf("Directory not found: %s\n", parent_path);
        return;
    }

    if (findDirectory(parentDir, dir_name) != NULL) {
        printf("Directory already exists: %s\n", path);
        return;
    }

    if (parentDir->subdirectory_count < MAX_FILES) {
        Directory *newDir = (Directory *)malloc(sizeof(Directory));
        strcpy(newDir->name, dir_name);
        newDir->subdirectory_count = 0;
        newDir->file_count = 0;
        parentDir->subdirectories[parentDir->subdirectory_count++] = newDir;
        fs.num_dir++;
        printf("Directory created: %s\n", path);
    } else {
        printf("Maximum directory limit reached: %s\n", path);
    }
}

void removeDirectory(const char *path) {
    char parent_path[MAX_PATH_LEN];
    char dir_name[FILENAME_LEN];
    splitPath(path, parent_path, dir_name);

    Directory *parentDir = navigateToDirectory(parent_path);
    if (parentDir == NULL) {
        printf("Directory not found: %s\n", parent_path);
        return;
    }

    for (int i = 0; i < parentDir->subdirectory_count; i++) {
        if (strcmp(parentDir->subdirectories[i]->name, dir_name) == 0) {
            if (parentDir->subdirectories[i]->file_count > 0) {
                printf("Directory not empty: %s\n", path);
                return;
            }
            free(parentDir->subdirectories[i]);
            for (int j = i; j < parentDir->subdirectory_count - 1; j++) {
                parentDir->subdirectories[j] = parentDir->subdirectories[j + 1];
            }
            parentDir->subdirectory_count--;
            printf("Directory deleted: %s\n", path);
            fs.num_dir--;
            return;
        }
    }
    printf("Directory not found: %s\n", path);
}

int main() {
    char command[256];
    char arg1[256], arg2[256], arg3[256], arg4[256], arg5[256];
    float block_size = BLOCK_SIZE;
    char file_system_name[MAX_FILENAME];
    
    
    while (1) {
        printf("> ");
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = 0; // Remove trailing newline

        if (sscanf(command, "makeFileSystem %f %s", &block_size, file_system_name) == 2) {
            createFileSystem(file_system_name, block_size);
            saveFileSystem(file_system_name);
        } else if (sscanf(command, "fileSystemOper %s %s %s %s %s", arg1, arg2, arg3, arg4, arg5) >= 2) {
            loadFileSystem(arg1); // Load the specified file system
            
            removeQuotes(arg3);
            
            if (strcmp(arg2, "dir") == 0) {
                listDirectory(arg3);
            } else if (strcmp(arg2, "dumpe2fs") == 0) {
                dumpFileSystem();
            } else if (strcmp(arg2, "write") == 0) {
                writeToFile(arg3, arg4,arg5);
            } else if (strcmp(arg2, "read") == 0) {
                readFromFile(arg3, arg4, arg5);
            } else if (strcmp(arg2, "del") == 0) {
                deleteFile(arg3);
            } else if (strcmp(arg2, "chmod") == 0) {
                chmodFile(arg3, arg4);
            } else if (strcmp(arg2, "addpw") == 0) {
                addPassword(arg3, arg4);
            } else if (strcmp(arg2, "mkdir") == 0) {
                makeDirectory(arg3); 
            } else if (strcmp(arg2, "rmdir") == 0) {
                removeDirectory(arg3);
            } else {
                printf("Unknown operation: %s\n", arg2);
            }
            saveFileSystem(arg1); // Save the file system after each operation
        } else {
            printf("Unknown command: %s\n", command);
        }
    }

    return 0;
}
